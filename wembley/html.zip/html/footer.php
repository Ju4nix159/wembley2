<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../html/admin/js/jquery.min.js"></script>

<!-- Bootstrap 4 -->
<script src="../html/admin/js/bootstrap.bundle.min.js"></script>


<!-- AdminLTE App -->
<script src="../html/admin/js/adminlte.min.js"></script>



<!-- PAGE PLUGINS -->

<!-- jQuery Mapael -->

<script src="../html/admin/js/jquery.mousewheel.js"></script>
<script src="../html/admin/js/raphael.min.js"></script>
<script src="../html/admin/js/jquery.mapael.min.js"></script>
<script src="../html/admin/js/usa_states.min.js"></script>

<!-- ChartJS -->
<script src="../html/admin/js/Chart.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="../html/admin/js/jquery.dataTables.min.js"></script>
<script src="../html/admin/js/dataTables.bootstrap4.min.js"></script>
<script src="../html/admin/js/dataTables.responsive.min.js"></script>
<script src="../html/admin/js/responsive.bootstrap4.min.js"></script>
<script src="../html/admin/js/dataTables.buttons.min.js"></script>
<script src="../html/admin/js/buttons.bootstrap4.min.js"></script>
<script src="../html/admin/js/pdfmake.min.js"></script>


</body>
</html>
