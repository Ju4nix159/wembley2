<?php
    session_start();
    require '../config/database.php';

    $db = new Database();
    $con = $db->conectar();
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>

     <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../html/admin/css/fontawesome-free/css/all.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="../html/admin/css/bootstrap-4.min.css">
    <!-- Toastr -->
    <link rel="stylesheet" href="../html/admin/css/toastr.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../html/admin/css/adminlte.min.css">



    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <link rel="stylesheet" href="../style/style.css">
</head>
<body>
    <div class="head">
        <div class="logo">
            <a href="pagina_principal.php"><img src="../imagen/logo.png" alt="Logo" height="70px" width="100%"></a>
        </div>

        <nav class="navbar">
            <a href="contacto.php">Contacto</a>
            <a href="catalogo.php">Catálogo</a>
            <?php if (isset($_SESSION['id_usuario']) && $_SESSION['permisos'] == 1) { ?>
                    <a href="paneluser.php">Panel de Usuario</a>

            <?php } else if(isset($_SESSION['id_usuario']) && $_SESSION['permisos'] == 2){ ?>
|                   <a href="paneluser.php">Panel de usuario-administrador</a>
                    <a href="admin/dashboard.php">Panel de AdministradorLTE</a>

            <?php }else{ ?>
                    <a href="login.php">Iniciar Sesión</a>
                    <a href="registro.php">Registro</a>
            <?php }
            
            if(isset($_SESSION['id_usuario'])) {?>
                <a href="logout.php">Cerrar sesion</a>
            <?php } ?>
            <div class="contenedor_icono">
                <div class="contenedor_icono_carrito">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        class="icono_carrito"
                        >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"
                        />
                    </svg>
                    <div class="contador_productos">
                        <span>0</span>
                    </div>
               </div>
    
                <div class="contenedor_carrito hidden">
                    <div class="contenedor_carrito__productos hidden"></div>

                    <div class="contenedor_carrito__total hidden">
                        <h3>Total:</h3>
                        <h2 class="total_pagar"></h2>
                    </div>
                    <div class="comprar_carrito hidden">
                        
                        <button class="boton_principal">Comprar ahora</button>
                    </div>
                        
                    <p class="contenedor_carrito__carro_vacio">El carrito está vacío</p>
                </div>
            </div>
        </nav>
    </div>
    <script src="../js/carrito.js"></script>
</body>
</html>
