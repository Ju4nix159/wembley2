<?php   
    include 'header.php'; 
    
    $db = new Database();
    $con = $db->conectar();
    $sql = $con->prepare("SELECT * FROM productos WHERE destacado = 1");
    $sql->execute();
    $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    
    
    <link rel="shortcut icon" href="../imagen/icono.ico" type="image/x-icon">

    <title>WEMBLEY</title>
</head>

<body>

    <section class="banner">
        <h1 class="titulo">WEMBLEY</h1>
        <p class="texto">Somos un emprendimiento de venta de botines de futbol</p>
        <div class="boton_saberMas">
            <a href="https://www.instagram.com/wembleyutileria/" target="_blank" class="boton_principal">Saber mas</a>
        </div>
    </section>

    <section class="destacados"> 
        <h2 class="titulo centrar">DESTACADOS</h2>
        <button class="izquierda_boton"><img src="../imagen/arrow.png" alt=""></button>
        <button class="derecha_boton"><img src="../imagen/arrow.png" alt=""></button>
        <div class="destacados__contenedor">
            <?php foreach($resultado as $row) { ?>
                <div class="destacados__card">
                    <div class="destacados__imagen">
                    <?php
                            $imagen_referencia = $row['img'];

                            // Verifica si se ha proporcionado una referencia de imagen
                            if (!empty($imagen_referencia)) {
                                // Puedes ajustar la ruta o el formato de la referencia según tu estructura de archivos
                                $ruta_imagen = '../imagen/botines/'.$imagen_referencia;

                                // Verificar si la imagen existe en la ruta proporcionada
                                if (file_exists($ruta_imagen)) {
                                    // Si la imagen existe, muestra la imagen
                                    echo '<img class="imagen" src="' . $ruta_imagen . '" alt="Imagen del producto">';
                                } else {
                                    // Si la imagen no existe, muestra una imagen de respaldo
                                    echo '<img class="imagen" src="../imagen/nophoto.png" alt="Imagen no disponible">';
                                }
                            } else {
                                // Si no se proporcionó una referencia de imagen, muestra una imagen de respaldo
                                echo '<img class="imagen" src="../imagen/nophoto.png" alt="Imagen no disponible">';
                            }
                        ?>
                        <a class="detalle_boton" href="detalle.php?id_producto=<?php echo $row['id_producto']; ?>" >Detalle</a>
                    </div>
                    <div class="destacados__info">
                        <h2 class="destacados__titulo centrar"><?php echo $row['nombre']; ?></h2>
                        <?php
                            if ($row['descuento'] > 0) {
                                // Si el descuento es mayor que 0, muestra el precio de descuento
                                $precio = $row['precio_desc'];
                            } else {
                                // Si el descuento es igual a 0, muestra el precio original
                                $precio = $row['precio'];
                            }
                        ?>
                        <h3 class="precio centrar"><?php echo $precio; ?></h3>
                    </div>
                </div>
            <?php } ?>   
        </div>
        
    </section>



    <section class="content  jugador">
            <h2 class="titulo">Clientes</h2>
    </section>

    <section class="content centrar about">
        <h2 class="titulo">Nosotros</h2>

        <p class="texto">
            ¡Somos Wembley!
            <br>
            Emprendimiento ubicado en Río Tercero, donde vamos a ofrecerles distintos productos como botines de fútbol, indumentaria y accesorios para el deporte.
            Respondemos sus consultas y les informamos todo lo que se viene.
        </p>

        <div class="boton_saberMas">
            <a href="https://www.instagram.com/wembleyutileria/" target="_blank" class="boton_principal">Saber mas</a>
        </div>
    </section>
    <script src="../js/script.js"></script>

</body>
</html>