<?php
    include 'header.php';

    
    $db = new Database();
    $con = $db->conectar();

    $sesion_iniciada = (isset($_SESSION['email']) && !empty($_SESSION['email']));


    $id_producto = $_GET['id_producto'];

    $sql_detalle_producto = $con->prepare("SELECT count(id_producto) FROM productos WHERE id_producto= :id_producto");
    $sql_detalle_producto->bindParam(':id_producto', $id_producto);
    $sql_detalle_producto->execute();

    if($sql_detalle_producto->fetchColumn() > 0){
        $sql = $con->prepare("SELECT * FROM productos WHERE id_producto=? LIMIT 1");
        $sql->execute([$id_producto]);
        $row = $sql-> fetch(PDO::FETCH_ASSOC);
        $nombre = $row['nombre'];
        $descripcion = $row['descripcion'];
        $precio = $row['precio'];
    }
?>

    
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="../imagen/icono.ico" type="image/x-icon">
        <title>Detalle</title>
    </head>
    <body>
        <main>

            <div class="contenedor_detalle_producto">
                <div class = "grid_contenedor">
                    <div class = "detalle_img">
                        <?php
                            // Suponiendo que $row contiene los datos de tu base de datos
                            $imagen_referencia = $row['img'];

                            // Verifica si se ha proporcionado una referencia de imagen
                            if (!empty($imagen_referencia)) {
                                // Puedes ajustar la ruta o el formato de la referencia según tu estructura de archivos
                                $ruta_imagen = '../imagen/botines/'.$imagen_referencia;

                                // Verificar si la imagen existe en la ruta proporcionada
                                if (file_exists($ruta_imagen)) {
                                    // Si la imagen existe, muestra la imagen
                                    echo '<img src="' . $ruta_imagen . '" alt="Imagen del producto">';
                                } else {
                                    // Si la imagen no existe, muestra una imagen de respaldo
                                    echo '<img src="../imagen/nophoto.png" alt="Imagen no disponible">';
                                }
                            } else {
                                // Si no se proporcionó una referencia de imagen, muestra una imagen de respaldo
                                echo '<img src="../imagen/nophoto.png" alt="Imagen no disponible">';
                            }
                        ?>
                    </div>
                    <div class = "detalle_informacion">
                        <h2><?php echo $nombre ?></h2>
                        <h2><?php echo '$' . number_format($precio,2,'.', ',')?></h2>
                        <p><?php echo $descripcion ?> </p>

                        <div class = "detalle_botones">
                            <a class= "boton_principal" href="catalogo.php">catalogo</a>
                            <?php if ($sesion_iniciada) : ?> <!-- verifica la sesion muestra un boton -->
                                    <a class="boton_principal boton__agregar" data-producto-id="<?php echo $id; ?>" data-producto-nombre="<?php echo $row['nombre']; ?>" data-producto-precio="<?php echo $row['precio']; ?>">Agregar</a>
                                <?php else : ?>
                                    <!-- Mostrar un botón plano sin PHP si no hay sesión iniciada -->
                                    <div class="boton_sin_sesion">

                                        <a class="boton_principal">Agregar</a>
                                    </div>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
</html>