
<?php
  
  include '../admin/header.php';
  include '../admin/aside.php';
  include '../admin/footer.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Añadir Producto</title>


</head>
<div class="wrapper">


  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Añadir Producto</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">inicio</a></li>
              <li class="breadcrumb-item"><a href="productos.php">productos</a></li>
              <li class="breadcrumb-item active">Añadir Producto</></li>
              
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->



    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-8">
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Añadir Producto</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->

              <form class="form-horizontal" action="procesar_bd.php" method="POST" enctype="multipart/form-data">
                <div class="card-body">

                  <div class="form-group row">
                    <label for="n_producto" class="col-sm-2 col-form-label">N_producto</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="n_producto" name="n_producto" required>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="descripcion" class="col-sm-2 col-form-label">Descripción</label>
                    <div class="col-sm-10">
                      <textarea id="descripcion" class="form-control" rows="3" name="descripcion"></textarea>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="precio" class="col-sm-2 col-form-label">Precio</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="precio" name="precio" required>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="precio_descuento" class="col-sm-2 col-form-label">Precio descuento</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="precio_descuento" name="precio_descuento" >
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="descuento" class="col-sm-2 col-form-label">% descuento</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="descuento" name="descuento"  >
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="destacado" class="col-sm-2 col-form-label">Destacado</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="destacado" name="destacado" >
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="referencia_imagen" class="col-sm-2 col-form-label">Referencia Imagen</label>
                    <div class="col-sm-10">
                        <input name="referencia_imagen" type="file" class="form-control-file" id="referencia_imagen" >
                        <p class="help-block">Añadir referencia a una imagen del producto.</p>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="id_categoria" class="col-sm-2 col-form-label">Categoría</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="id_categoria" name="id_categoria" required>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="stock" class="col-sm-2 col-form-label">stock</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="stock" name="stock" required>
                    </div>
                  </div>

                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" name="añadir_producto" class="btn btn-info">Guardar</button>
                  <a class="btn btn-default float-right" href="productos.php">Cancelar</a>
                </div>
                <!-- /.card-footer -->
              </form>


            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  
</div>
<!-- ./wrapper -->
<script src="../admin/js/app.js"></script>

</body>
</html>
