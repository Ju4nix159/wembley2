<?php
    include 'header.php';

    $db = new Database();
    $con = $db->conectar();

    $sql = $con->prepare("SELECT * FROM productos");
    $sql->execute();
    $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);

    $sesion_iniciada = (isset($_SESSION['email']) && !empty($_SESSION['email']));

    // Obtener categorías
    $categorias_sql = $con->prepare("SELECT * FROM categoria");
    $categorias_sql->execute();
    $categorias = $categorias_sql->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../imagen/icono.ico" type="image/x-icon">

    <title>catalogo</title>
</head>
<body>
    <main>
        <div class="contenedor_catalogo">

            <div class="filtro_categoria">

                <label>Filtrar por categoría:</label>
                <div class="categorias-checkbox">
                    <?php foreach ($categorias as $categoria) { ?>
                    <label>
                        <input type="checkbox" class="categoria-checkbox" value="<?php echo $categoria['id_categoria']; ?>">
                        <?php echo $categoria['nombre_categorias']; ?>
                    </label>
                    <?php } ?>
                </div>
                
                <div class="ordenar">
                    <label>Ordenar por:</label>
                    <button class="boton_secundario" id="ordenarPrecio">Precio <i class='bx bx-chevron-down'></i> </button>
                    
                    <button class="boton_secundario" id="ordenarAlfabeticamente">Alfabéticamente <i class='bx bx-chevron-down'></i></button>
                </div>

                <div class="buscar">
                    <label>Buscar:</label>
                    <input type="text" id="buscarProducto" placeholder="Escribe para buscar...">
                </div>

            </div>
            <div class="pop_up_catalogo hidden">
                <h2>No se puede agregar productos al carrito. Inicia sesión o registrate.</h2>
                <a class="boton_principal" href="login.php">iniciar sesion</a>
                <a class="boton_principal" href="registro.php">registrarme</a>
                <a class="cancelar_btn" >cancelar</a>
            </div>
            <div class="grid_contenedor" id="gridContenedor">
                
                <?php foreach ($resultado as $row) { ?>
                    <div class="carta" data-categoria="<?php echo $row['id_categoria']; ?>">
                    <?php
                                // Suponiendo que $row contiene los datos de tu base de datos
                                $imagen_referencia = $row['img'];

                                // Verifica si se ha proporcionado una referencia de imagen
                                if (!empty($imagen_referencia)) {
                                    // Puedes ajustar la ruta o el formato de la referencia según tu estructura de archivos
                                    $ruta_imagen = '../imagen/botines/'.$imagen_referencia;

                                    // Verificar si la imagen existe en la ruta proporcionada
                                    if (file_exists($ruta_imagen)) {
                                        // Si la imagen existe, muestra la imagen
                                        echo '<img src="' . $ruta_imagen . '" alt="Imagen del producto" class="producto__imagen">';
                                    } else {
                                        // Si la imagen no existe, muestra una imagen de respaldo
                                        echo '<img src="../imagen/nophoto.png" alt="Imagen no disponible" class="producto__imagen">';
                                    }
                                } else {
                                    // Si no se proporcionó una referencia de imagen, muestra una imagen de respaldo
                                    echo '<img src="../imagen/nophoto.png" alt="Imagen no disponible" class="producto__imagen">';
                                }
                            ?>
                        <div class="carta__informacion">
                            
                            <div class="carta__titulo"><?php echo $row['nombre']; ?></div>
                            <div class="carta__precio"><?php echo number_format($row["precio"], 2, '.', ','); ?></div>
                            <div class="carta__botones">
                                <a  href="detalle.php?id_producto=<?php echo $row['id_producto']; ?>" class="boton_principal">Detalle</a>

                                <?php if ($sesion_iniciada) : ?> <!-- verifica la sesion muestra un boton -->
                                    <a class="boton_principal boton__agregar" data-producto-id="<?php echo $row['id_producto']; ?>" data-producto-nombre="<?php echo $row['nombre']; ?>" data-producto-precio="<?php echo $row['precio']; ?>">Agregar</a>
                                <?php else : ?>
                                    <!-- Mostrar un botón plano sin PHP si no hay sesión iniciada -->
                                    <div class="boton_sin_sesion">

                                        <a class="boton_principal" id="agregar_no_sesion">Agregar</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="../js/filtro.js"></script>
    <script src="../js/pop_up_catalogo.js"></script>
</body>
</html>
